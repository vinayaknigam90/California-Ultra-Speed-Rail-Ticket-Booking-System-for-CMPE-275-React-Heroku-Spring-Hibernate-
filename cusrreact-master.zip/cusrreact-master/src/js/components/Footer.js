import React from "react";


export default class Footer extends React.Component {
  render() {
    return (

      <footer><br/><br/><br/><br/><br/>CMPE 275 Project for Fall 2017 by Aaditya, Pranav, Saumya and Vinayak</footer>
      
    );
  }
}
